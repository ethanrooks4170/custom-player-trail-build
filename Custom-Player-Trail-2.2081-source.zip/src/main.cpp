#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include "color/colorConversion.cpp"

using namespace geode::prelude;

class $modify(CustomTrailLayer, PlayLayer) {
    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);

        auto* mod = Mod::get();
        bool disabled = mod->getSettingValue<bool>("disable-trail");
        bool hideWave = mod->getSettingValue<bool>("disable-trail-in-wave");
        bool rainbow = mod->getSettingValue<bool>("enable-rainbow");
        bool custom = mod->getSettingValue<bool>("enable-custom-color");

        cocos2d::ccColor3B first{}, second{};
        bool recolor = !disabled && (rainbow != custom);
        if (recolor && rainbow) {
            auto saturation = mod->getSettingValue<double>("saturation");
            auto brightness = mod->getSettingValue<double>("brightness");
            auto offset = mod->getSettingValue<double>("offset");
            first = getRGB(offset + 1, saturation, brightness);
            second = mod->getSettingValue<bool>("invert-player-2")
                ? getRGB(offset + 180, saturation, brightness) : first;
            hue_base = std::fmod(hue_base + mod->getSettingValue<double>("speed") / 10, 360.0);
        } else if (recolor) {
            first = mod->getSettingValue<cocos2d::ccColor3B>("color-P1");
            second = mod->getSettingValue<cocos2d::ccColor3B>("color-P2");
        }

        auto updateTrail = [&](PlayerObject* player, cocos2d::ccColor3B color) {
            if (!player || !player->m_regularTrail) return;
            auto* trail = player->m_regularTrail;
            if (recolor) trail->setColor(color);
            if (disabled || hideWave || !player->m_isDart)
                trail->setVisible(!disabled && !(hideWave && player->m_isDart));
        };
        updateTrail(m_player1, first);
        updateTrail(m_player2, second);
    }
};
